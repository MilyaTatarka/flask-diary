from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_required, login_user, current_user, logout_user

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'my-secret-key-123'

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


# ─── Модели БД (пункт 02) ───────────────────────────────────
class Users(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)


class Card(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    subtitle = db.Column(db.String(200), nullable=True)
    text = db.Column(db.Text, nullable=False)


@login_manager.user_loader
def load_user(user_id):
    return db.session.query(Users).get(user_id)


# ─── Создание таблиц при первом запуске ─────────────────────
with app.app_context():
    db.create_all()


# ─── Маршруты (пункт 03) ────────────────────────────────────

# Home -> login или registration
@app.route('/home')
def home():
    return render_template('home.html')


# Registration -> login
@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not password:
            return render_template('register.html', error="Заполните все поля")

        existing = Users.query.filter_by(username=username).first()
        if existing:
            return render_template('register.html', error="Такой логин уже занят")

        hashed = generate_password_hash(password)
        new_user = Users(username=username, password=hashed)
        db.session.add(new_user)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('register.html')


# Login -> index (при успехе) или home
@app.route("/login/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        user = Users.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('index'))

        return render_template('login.html', error="Неверный логин или пароль")

    return render_template('login.html')


# Logout
@app.route('/logout/')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))


# Index -> create или card/номер (пункт 04, 05, 06)
@app.route('/')
@login_required
def index():
    cards = Card.query.order_by(Card.id.desc()).all()
    return render_template('index.html', cards=cards, user=current_user)


# Create -> index (пункт 04, 05)
@app.route('/create')
@login_required
def create():
    return render_template('create.html')


# Форма создания карточки (пункт 05)
@app.route('/form_create', methods=['GET', 'POST'])
@login_required
def form_create():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        subtitle = request.form.get('subtitle', '').strip()
        text = request.form.get('text', '').strip()

        if title and text:
            new_card = Card(title=title, subtitle=subtitle, text=text)
            db.session.add(new_card)
            db.session.commit()

        return redirect(url_for('index'))

    return redirect(url_for('create'))


# Card/номер_карточки -> index (пункт 03)
@app.route('/card/<int:id>')
@login_required
def card(id):
    card_item = Card.query.get_or_404(id)
    return render_template('card.html', card=card_item)


if __name__ == "__main__":
    app.run(debug=True)
